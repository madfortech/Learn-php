<?php  include 'do-while.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>function php</title>
</head>
<body>
   
   <?php
    
    function plussim(){
        $fo = 2;
        $go = 4;
        if($fo > $go){
            echo "no";
        }
        
        else{
            echo "yes";
        }
        
    }
    
    plussim();
    
    ?>
    
</body>
</html>