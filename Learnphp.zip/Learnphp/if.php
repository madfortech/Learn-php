<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>If else statement</title>
</head>
<body>
    
    <?php
    
    $rt = 4;
    $st = 4;
    
    if($rt < $st){
        echo "yes";
    }
    
    elseif($rt == $st){
        echo "yes yes";
    }
    
    else{
        echo "no";
    }
    
    ?>
    
    
</body>
</html>