<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>while loop</title>
</head>
<body>
    
    <?php
    
    $fg = 2;
    
    while($fg <= 10){
        echo $fg;
        $fg++;
    }
    
    ?>
    
</body>
</html>