<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data type</title>
</head>
<body>
    
    <?php
    
    $name = "himanshu";
    $rollnu = 'nishad';
    
    $number = 1233;
    
    $dec  =12.2;
    
    $con = "";
    
    var_dump( $con);
    
    ?>
    
</body>
</html>