<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Arithmetic Operator</title>
</head>
<body>
   
   <?php
    
    $num1 = 2;
    $num2 = 2;
//    $num3 = $num1 + $num2;
    
//    $num3 = $num1 - $num2;
    
//     $num3 = $num1 * $num2;
    
     $num3 = $num1 / $num2;
    
    echo $num3;
    
    ?>
    
</body>
</html>