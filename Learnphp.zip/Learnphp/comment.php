<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>learn comment</title>
</head>
<body>
   
   <?php
    
    $name = 11.1; /* this is variable gggiiiiiiiiiiiiiiiiiiiiiiiiiiiii
    ddbdbdbdbdbd
        ddnnddndnnd
        dddndndd
        ndndnnd
     */
    echo $name ; // this is echo this is single line comment
    
    ?>
    
</body>
</html>

