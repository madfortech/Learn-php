<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>learn variable</title>
</head>
<body>
   
   <?php
    
    $name = 11.1;
    $NAME = "JWJWWJ";
    $name_Hia ="";
    
    echo $name ."<br>". $NAME;
    
    
    ?>
    
</body>
</html>


