<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>array php</title>
</head>
<body>
    
    <?php
    
    $df = array("himanshu",12.2,22);
    
   $df[0]= 22222;
    
    echo $df[0]. "<br>". $df[1];
    
    
    ?>
    
    
</body>
</html>