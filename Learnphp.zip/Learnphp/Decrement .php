<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Decrement operators</title>
</head>
<body>
    
    <?php
    
    $ro = 2;

    echo --$ro;
    
    ?>
    
    
</body>
</html>