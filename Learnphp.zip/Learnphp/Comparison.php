<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Comparison Operators</title>
</head>
<body>
    
    <?php
    
    $him = 2;
    $sim = 42;
    $pim = $him <= $sim;
    
    echo    $pim;
    
    ?>
    
</body>
</html>