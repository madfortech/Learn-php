<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assignment operators</title>
</head>
<body>
    
    <?php
    
    $gee = 2;
    $gee += 5;
    
    var_dump( $gee)
        
        .
        
        
        
        ;
    ?>
    
</body>
</html>