<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>super global php</title>
</head>
<body>
    
    <?php
    
//    $fo = $_SERVER['PHP_SELF'];

     $ho = $_SERVER['HTTP_REFERER'];
    
    echo $ho;
    
    ?>
    
    
</body>
</html>