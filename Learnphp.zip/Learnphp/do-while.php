<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Do while </title>
</head>
<body>
    
    <?php
    
    plussim();
    
//    $jo = 26;
//    
//    do{
//        echo $jo;
//        $jo++;
//    }while($jo <= 10);
//    
    
    
    ?>
    
</body>
</html>